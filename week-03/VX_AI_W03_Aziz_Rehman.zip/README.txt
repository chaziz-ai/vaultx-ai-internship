VaultX AI Internship — Week 03 Submission
Aziz ur Rehman

Contents of this ZIP:
- workflows/        -> Exported n8n workflow JSON files (Automation #1: Inbox Triage, Automation #2: Content Pipeline)
- screenshots/       -> Screenshots of live automated runs, structured-LLM branching, and failed-then-recovered run
- runbook/           -> One-page runbook PDF (what it does, trigger, cost, how to fix it)

GitHub Repository:
https://github.com/chaziz-ai/vaultx-ai-internship

Demo + Walkthrough Video (Google Drive):
https://drive.google.com/file/d/1jsiKrx7RWahuP_T_pTNNbmU0jg6MS7gg/view?usp=sharing
